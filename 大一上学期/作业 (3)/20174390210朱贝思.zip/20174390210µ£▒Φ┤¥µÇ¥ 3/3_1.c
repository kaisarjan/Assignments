#include<stdio.h>
main()
{
	float x,y;
	scanf("%f",&x);
	switch((int)x/10)
	{
	case 0:y=x;break;
    case 1:y=x*2+3;break;
	case 2:y=-0.5*x+10;break;
	}
	printf("y=%f",y);
}
