#include<stdio.h>
main()
{
    int number;
    printf("���룺");
    scanf("%d",&number);
    {
        if (number%3==0&&number%4==0&&number%5==0)
        printf("yes\n");
        else
        printf("no\n");
    }
}
