/*3_5*/
/*三角形问题（2）*/
#include <stdio.h>
#include <math.h>
int main (void)
{
        float a=0,b=0,c=0;
        printf("请输入三边边长：");
        scanf("%f%f%f",&a,&b,&c);
        if((a+b>c)&&(a+c>b)&&(b+c>a)&&(fabs(a-b)<c)&&(fabs(a-c)<b)&&(fabs(b-c)<a))
        {
                if(a==b&&a==c&&b==c)
                        printf("\n该三角形为等边三角形");
                else if(a==b||a==c||b==c)
                        printf("\n该三角形为等腰三角形");
                else if(a*a+b*b==c*c||a*a+c*c==b*b||b*b+c*c==a*a)
                        printf("该三角形为直角三角形");
                else printf("该三角形为一般三角形");
        }
        else printf("\n您输入的数值可能无法构成三角形，请检查后再试。");
}
