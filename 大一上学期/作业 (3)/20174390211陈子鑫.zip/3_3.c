/*3_3*/
/*税率、税款、奖金*/
#include <stdio.h>
int main (void)
{
        float ma,tr,ma_after_tax,tax;
        printf("Please input money award:");
        scanf("%f",&ma);
        switch((int)ma/1000)
        {
        case 0:   tr=0;  tax=ma*(tr*0.01); ma_after_tax=ma;
                printf("Tax rate is %g%%\nTax is %g\nMoney Award after tax is %g",tr,tax,ma_after_tax);
                break;
        case 1:   tr=5;  tax=ma*(tr*0.01); ma_after_tax=ma-tax;
                printf("Tax rate is %g%%\nTax is %g\nMoney Award after tax is %g",tr,tax,ma_after_tax);
                break;
        case 2:
        case 3:   tr=8;  tax=ma*(tr*0.01); ma_after_tax=ma-tax;
                printf("Tax rate is %g%%\nTax is %g\nMoney Award after tax is %g",tr,tax,ma_after_tax);
                break;
        default: tr=10; tax=ma*(tr*0.01); ma_after_tax=ma-tax;
                printf("Tax rate is %g%%\nTax is %g\nMoney Award after tax is %g",tr,tax,ma_after_tax);
                break;
        }
}
