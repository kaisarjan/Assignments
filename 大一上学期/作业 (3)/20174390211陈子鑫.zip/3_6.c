/*3_6*/
/*能否被3、4、5整除*/
#include <stdio.h>
int main(void)
{
        int num;
        printf("Please input an integer:");
        scanf("%d",&num);
        switch(num%3==0&&num%4==0&&num%5==0)
        {
        case 0:   printf("\n%d不能被3、4、5同时整除。",num);
                break;
        case 1:   printf("\n%d可以被3、4、5同时整除。",num);
                break;
        default: {}
        break;
        }
}
