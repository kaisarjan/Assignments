/*3_7*/
/*ÊÇ·ñÈòÄê*/
#include <stdio.h>
int main(void)
{
        int year;
        printf("Please input year:");
        scanf("%d",&year);
        switch(year%4==0&&year%100!=0||year%400==0)
        {
        case 0:   printf("\n%d is not a leap year.",year);
                break;
        case 1:   printf("\n%d is a leap year.",year);
                break;
        default: {}
        break;
        }
}
