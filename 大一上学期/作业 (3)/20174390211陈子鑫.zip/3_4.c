/*3_4*/
/*由大到小顺序输出*/
#include <stdio.h>
int main (void)
{
        int a,b,c,d;
        int tmp;
        int i,j,k;
        printf("Please input integer a,b,c,d:");
        scanf("%d%d%d%d",&a,&b,&c,&d);
        int Array[]={a,b,c,d};
        for(i=0; i<=3; i++)
        {
                k=i;
                for(j=i+1; j<=3; j++)
                {
                        if(Array[j]<Array[k])
                                k=j;
                }
                if(i!=k)
                {
                        tmp=Array[i];
                        Array[i]=Array[k];
                        Array[k]=tmp;
                }
                printf("%d  ",Array[i]);
        }
}
