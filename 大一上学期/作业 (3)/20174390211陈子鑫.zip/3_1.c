/*3_1*/
/*int语句改写switch语句*/
#include <stdio.h>
main(void)
{
        float x,y=0;
        printf("请输入x：\n");
        scanf("%f",&x);
        switch((int)x/10)
        {
        case 0:   y=x;
                break;
        case 1:   y=x*2+3;
                break;
        case 2: case 3:   y=(-0.5)*x+10;
                break;
        default: printf("Error\n");
        }
        printf("y的值为%g",y);
}
