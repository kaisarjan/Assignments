#include<stdio.h>
main()
{
    int i,n,a,b,c;
    for(i=5;i>=1;i--)
    { for(a=1;a<=5-i;a++)
            printf("\t");
        for(n=1;n<=i;n++)
        {
            printf("*");
            printf("\t\t");
        }
         printf("\n");

    }
    for(i=2;i<=5;i++)
    {  for(c=1;c<=5-i;c++)
    printf("\t");
        for(b=1;b<=i;b++)
      {
        printf("*");
        printf("\t\t");
      }
      printf("\n");

    }
}
