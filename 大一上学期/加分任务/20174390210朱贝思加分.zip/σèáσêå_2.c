#include<stdio.h>
main()
{
    int a,b,c,d,s;
    a=1000/5;
    b=1000/25;
    c=1000/125;
    d=1000/625;
    s=a+b+c+d;
    printf("%d\n",s);
}
