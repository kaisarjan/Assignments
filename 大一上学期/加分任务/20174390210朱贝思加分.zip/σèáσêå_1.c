#include<stdio.h>
main()
{
    int a,b,c;
    for(a=1;a<10;a++)
    {
        for(b=1;b<=a;b++)
        {
            c=a*b;
            printf("%d*%d=%d\t",b,a,c);
        }
        printf("\n");
    }
}
