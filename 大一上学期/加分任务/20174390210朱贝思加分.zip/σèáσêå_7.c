#include<stdio.h>
main()
{
    int i,a,b,c;
    for(i=1;i<=5;i++)
    {
        for(a=1;a<=5-i;a++)
        {
            printf(" ");
        }
        for(b=1;b<=i;b++)
        {
            printf("%d",b);
        }
        for(c=i-1;c>0;c--)
            printf("%d",c);
        printf("\n");
    }
    for(i=1;5-i>0;i++)
       {
        for(a=1;a<=i;a++)
        printf(" ");
    for(b=1;b<=5-i;b++)
        printf("%d",b);
    for(c=4-i;c>0;c--)
        printf("%d",c);
    printf("\n");
       }
}
