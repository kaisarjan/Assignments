/*ex_2*/
/*How many 0 are there in the end of 1000!*/
#include <stdio.h>
int main(void)
{
        int a=1000,m=0;
        while(a>5)
        {
                a=a/5;
                m=m+a;
        }
        printf("There are %d ZEROS at the end of 1000!",m);
}
