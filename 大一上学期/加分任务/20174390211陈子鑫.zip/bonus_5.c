/*ex_5*/
/*Buy buy buy*/
#include <stdio.h>
int main(void)
{
        int rooster,hen,chicken;
        for(rooster=0; rooster<20; rooster++)
                for(hen=0; hen<(100-5*rooster)/3; hen++)
                {
                        chicken=100-rooster-hen;
                        if(chicken%3==0&&rooster*5+hen*3+chicken/3==100)
                                printf("Rooster:%d Hen:%d Chicken:%d\n",rooster,hen,chicken);
                }
}
