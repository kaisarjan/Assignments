/*ex_3*/
/*Han Xin`s roll-call*/
#include <stdio.h>
int main(void)
{
        int count=0;
        while(!(count%5==1&&count%6==5&&count%7==4&&count%11==10))
        {
                count++;
        }
        printf("There is %d people in Han Xin`s roll.\n",count);
}
