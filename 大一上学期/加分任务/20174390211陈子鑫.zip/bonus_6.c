/*ex_6*/
/*print out funnel*/
#include <stdio.h>
main()
{
        int row,i,k;
        for(row=0; row<=3; row++)
        {
                for(i=1; i<=row; i++)
                        printf(" ");
                for(i=1; i<=5-row; i++)
                        printf(" *");
                printf("\n");
        }
        for(row=1; row<=5; row++)
        {
                for(k=1; k<=5-row; k++)
                        printf(" ");
                for(k=1; k<=row; k++)
                        printf(" *");
                printf("\n");
        }
}
