/*ex_4*/
/*Einstein`s stairs*/
#include <stdio.h>
int main(void)
{
        int stairs=0;
        while(!(stairs%2==1&&stairs%3==2&&stairs%5==4&&stairs%6==5&&stairs%7==0))
        {
                stairs++;
        }
        printf("There is %d stairs.\n",stairs);
}
