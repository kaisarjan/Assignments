/*ex_7*/
/*print number pyramid*/
#include <stdio.h>
int main(void)
{
        int i,j,k,m;
        for(i=1; i<=5; i++)
        {
                for(m=1; m<=5-i; m++)
                        printf(" ");
                for(j=1; j<=i; j++)
                        printf("%d",j);
                for(k=j-2; k>=1; k--)
                        printf("%d",k);
                printf("\n");
        }
        for(i=1; i<=4; i++)
        {
                for(m=1; m<=i; m++)
                        printf(" ");
                for(j=1; j<=5-i; j++)
                        printf("%d",j);
                for(k=j-2; k>=1; k--)
                        printf("%d",k);
                printf("\n");
        }
}
