/*ex_1*/
/*print out multiplication table*/
#include <stdio.h>
int main(void)
{
        int a,b;
        printf("Below displays multiplication table:\n");
        for(a=1; a<=9; a++)
        {
                for(b=1; b<=a; b++)
                        if(a*b<=9)
                                printf("%d*%d= %d  ",a,b,a*b);
                        else printf("%d*%d=%d  ",a,b,a*b);
                printf("\n");
        }
}
