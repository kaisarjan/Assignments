#include<stdio.h>
#include<math.h>
main()
{
	int a,b,c,d,e,i,n,count=0;
	for(i=100;i<=10000;i++)
	{
		a=i%10;
		b=i/10%10;
		c=i/100%10;
		d=i/1000%10;
        n=0;
        e=i;
        while(e!=0)
		{
			e=e/10;
			n++;
		}
		if(pow(a,n)+pow(b,n)+pow(c,n)+pow(d,n)==i)
		{
		     printf("%d\t",i);
		     count++;
		}
	}
    printf("%d\n",count);
}

