#include<stdio.h>
#include<math.h>
main()
{
    double n,a=1,b=1,s=0;
    for(n=1;fabs(a)>1.e-6;)
    {
        s=s+a;
        n=n+2;
        b=-b;
        a=b/n;
    }
    printf("��/4=%lf",s);
}
