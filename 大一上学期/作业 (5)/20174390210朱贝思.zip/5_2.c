#include<stdio.h>
main()
{
	int i,x=2,count=0;
	for(;x<=10000;x++)
	{
		i=2;
		while(x%i!=0&&i<=x-1)
			i++;
		if(i==x)
		{
			count++;
		printf("%5d",x);
		}
	}
		printf("%8d\n",count);
}