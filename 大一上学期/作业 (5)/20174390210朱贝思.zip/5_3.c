#include<stdio.h>
main()
{
	int x,sum=0,count=0;
	for(x=1000;x<10000;x++)
	{
		if(x%10==6)
			if(x%4==0)
		{
			count++;
			sum=sum+x;
		}
	}
printf("%d\n",sum);
printf("%d\n",count);
}