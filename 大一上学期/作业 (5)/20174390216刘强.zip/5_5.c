#include<stdio.h>
main()
{
    int a,b,c,num=0;
    for (a=2;a<=1000;a++)
        {
            c=0;
    for(b=1;b<a;b++)
        if(a%b==0)
            c=c+b;
    if (c==a)
        {
            num++;
            printf("\n%d",a);
        }
}
printf("\nnum=%d",num);
}
