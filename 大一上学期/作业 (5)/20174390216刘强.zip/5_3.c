#include<stdio.h>
main()
{
    int a,count=0,sum=0;
    for(a=1000;a<=10000;a++)
    if(a%4==0&&a%10==6)
        {
            count++;
            sum+=a;
        }
    printf("count=%d",count);
    printf("\nsum=%d",sum);
}
