#include<stdio.h>
main()
{
    int a,b,count=0;
    for(a=2;a<=10000;a++)
    {
        for(b=2;b<=a/2;b++)
            if(a%b==0)break;
        if(b>a/2)
        {
            count++;
            printf("%d",a);
            if(count%1==0)
            printf("\t");
        }
     }
     printf("\ncount=%d",count);
}
