#include<stdio.h>
main()
{
    int n,a,b,c,num=0;
    for(n=100;n<1000;n++)
    {
        a=n%10;
        b=n/10%10;
        c=n/100;
        if(n==a*a*a+b*b*b+c*c*c)
        {
            printf("%d\n",n);
            num++;
        }
    }
    printf("%d",num);
}
