#include<stdio.h>
main()
{
    int a,b,c,num=0;
    for(a=0;a<=3;a++)
    for(b=1;b<=5;b++)
    for(c=0;c<=6;c++)
        if(a+b+c==6)
        printf("\nred:%d,white:%d,black:%d",a,b,c);
}
