#include<stdio.h>
#include<math.h>
main()
{
double s=0,pi,i,n;
for(i=2,n=1;fabs(1/n)>pow(10,-6);i++,n+=2)
s+=pow(-1,i)/n;
printf("pi=%lf\n",s*4);
}
