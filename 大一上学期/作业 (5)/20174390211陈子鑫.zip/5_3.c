/*5_3*/
/*numbers can be divided by 4 with 6 at last*/

#include<stdio.h>

int main(void)
{
    int m,n,sum=0;
    for(m=1000;m<=9999;m++)
    {
        if(m%10==6&&m%4==0)
        {
            printf("%6d",m);
            sum++;
        }
    }
    printf("\n%6d",sum);
}
