/*5_2*/
/*prime number*/

#include<stdio.h>

int main(void)
{
    int m,n,control,total=0;
    for(n=2;n<10000;n++)
    {
        for(m=2;m<n;m++)
        {
            if(n%m==0)
            break;
        }
        if(n==m)
        {
            printf("%6d",n);
            total++;
        }
        if(control%20==0)
            printf("\n");
    }
    printf("\n%6d",total);
}
