/*5_4*/
/*ball problem*/

#include <stdio.h>

int main(void)
{
        int i,j,k;
        for(i=0; i<=3; i++)
                for(j=1; j<=5; j++)
                        for(k=0; k<6; k++)
                        {
                                if(i+j+k==6)
                                        printf("%d %d %d \n",i,j,k );
                        }
}
