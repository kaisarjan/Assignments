/*5_7*/
/*digits alphas and blanks*/

#include <stdio.h>
#include <ctype.h>

int main(void)
{
        char Buffer[100];
        int i=0;
        int num_blanks=0,num_letters=0,num_numbers=0;
        gets(Buffer);
        while(Buffer[i]!='\0')
        {
                if(isalpha(Buffer[i]))
                        num_letters++;
                else if(isdigit(Buffer[i]))
                        num_numbers++;
                else if(isblank(Buffer[i]))
                        num_blanks++;
                i++;
        }
        printf("%d %d %d",num_letters,num_numbers,num_blanks );
}
