/*5_5*/
/*completed number*/

#include <stdio.h>

int main(void)
{
        int l,m,n;
        for(n=2; n<=1000; n++)
        {
                l=0;
                for(m=1; m<n; m++)
                {
                        if(n%m==0)
                        {
                                l=l+m;
                                if(l==n)
                                        printf("%d\n",n );
                        }
                }
        }
}
