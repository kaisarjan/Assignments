/*5_6*/
/*π/4=？*/

#include <stdio.h>
#include <math.h>

int main(void)
{
        double m=0,l=0,n;
        for(n=1;; n++)
        {
                l=pow(-1,(n+1))*(1/(2*n-1));
                m=m+l;
                if(fabs(l)<1e-6)
                        break;
        }
        printf("π/4=%g\n",m );
}
