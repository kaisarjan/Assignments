/*5_1*/
/*Narcissistic number*/

#include<stdio.h>

int main(void)
{
   int m,n,i,swap,a,total=0;
   float nnum=0;
   for(n=100;n<10000;n++)
   {
      m=n;
      for(i=0;m!=0;i++)
         {
             m=m/10;
         }
         m=n;
      for(nnum=0,swap=1;swap<=i;swap++)
         {
          nnum=nnum+pow(m%10,i);
          m=m/10;
         }
      if(nnum==n)
        {
            printf("%g ",nnum);
            total++;
        }
   }
}
