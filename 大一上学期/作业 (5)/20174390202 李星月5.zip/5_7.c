#include<stdio.h>
main()
{
    char t;
    int n1=0,n2=0,n3=0;
    do
    {
        scanf("%c",&t);
        if(t=='\n') break;
        else
        {
            if((t>='A'&&t<='Z')||(t>='a'&&t<='z'))
                n1++;
            if(t==' ')
                n2++;
            if(t>='0'&&t<='9')
                n3++;
        }
    }while(1);
    printf("�ַ�����%d�ո�����%d���ָ�����%d",n1,n2,n3);
}
