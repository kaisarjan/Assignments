#include<stdio.h>
main()
{
    int a,b,c;
    printf("a=����b=����c=����\n");
    for(a=1;a<=5;a++)
    {
        for(b=0;b<=3;b++)
        {
            for(c=5;c>=0;c--)
            {
                if(a+b+c==6)
                    printf("a=%db=%dc=%d\n",a,b,c);
            }
        }
    }
}
