#include<stdio.h>
main()
{
    int m,n,count=0;
    for(m=2;m<=10000;m++)
    {
        for(n=2;n<=m/2;n++)
        if(m%n==0) break;
         if(n>m/2)
        {printf("%5d",m);
        count++;
        }
    }
        printf("\ncount=%d",count);
}
