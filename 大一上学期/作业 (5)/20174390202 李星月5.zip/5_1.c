#include<stdio.h>
main()
{
	int m,a,b,c,d,count=0;
	for(m=100;m<1000;m++)
	{   a=m%10;
	    b=m/10%10;
		c=m/100%10;
		if(a*a*a+b*b*b+c*c*c==m)
		{   count++;
			printf("%5d",m);
		}
	}
	for(m=1000;m>=1000&&m<=10000;m++)
	{   a=m%10;
	    b=m/10%10;
		c=m/100%10;
		d=m/1000%10;
		if(a*a*a*a+b*b*b*b+c*c*c*c+d*d*d*d==m)
		{   count++;
		    printf("%5d",m);
		}
	}
	printf("\ncount=%d",count);
}