#include<stdio.h>
main()
{
    int m,sum=0;
    for(m=1000;m<=9999;m++)
    {if(m%4==0&&m%10==6)
       {sum++;
        printf("%5d",m);
       }
    }
    printf("\nsum=%d",sum);
}
