#include<stdio.h>
main()
{
    double m=1,n=1,sum=0,a,pi;
    do
    {
        a=m/n;
        sum+=a;
        m=-m;
        n=n+2;
    }
    while (fabs(a)>1.0e-6);
    printf("pi=%lf",4*sum);
}
