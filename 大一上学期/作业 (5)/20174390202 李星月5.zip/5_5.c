#include<stdio.h>
main()
{
    int m,n,i,sum,count=0;
    for(m=2;m<=1000;m++)
    {   sum=0;
        for(i=1;i<=m/2;i++)
        if(m%i==0)
       sum+=i;
        if(m==sum)
         {   count++;
             printf("%5d",m);
             n=m;
         }
    }
     printf("\ncount=%d\nn=%d\n",count,n);
}
