/*6_3*/
/*The Greatest Commom Divisor*/

#include <stdio.h>

int gcd(int m, int n)
{
        int r,temp;
        if (n < m)
        {
                temp = n;
                n = m;
                m = temp;
        }
        while (m != 0)
        {
                r = n%m;
                n = m;
                m = r;
        }
        return n;
}

int main(void)
{
        int n,m;
        printf("please input two intergers\n");
        scanf("%d%d", &n, &m);
        printf("The Greatest Commom Divisor of %d and %d is %d",m,n,gcd(m,n) );
}
