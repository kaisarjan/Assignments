/*6_5*/
/*factorial and power*/

#include <stdio.h>

float factorial(float n)
{
        float i,fac_result=1;
        for(i=1; i<=n; i++)
        {
                fac_result=fac_result*i;
        }
        return fac_result;
}
float power(float x,float n)
{
        float i=1,pow_result=1;
        while(i<=n)
        {
                pow_result=pow_result*x;
                i++;
        }
        return pow_result;
}
int main(void)
{
        float x,n,s=0;
        scanf("\n%f %f",&x,&n);
        s=s+factorial(n)/power(x,n);
        printf("\n%g",s);
}
