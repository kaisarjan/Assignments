/*6_1*/
/*sum of two number*/

#include <stdio.h>

float plus(float m,float n)
{
  return m+n;
}
int main(void)
{
  float m,n;
  scanf("%f%f\n",&m,&n);
  printf("\n%f",plus(m,n));
}
