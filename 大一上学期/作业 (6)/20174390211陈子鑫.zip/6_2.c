/*6_2*/
/*prime*/

#include <stdio.h>

int prime()
{
        int m,n,control=0,total=0;
        for(n=1; n<10000; n++)
        {
                for(m=2; m<n; m++)
                {
                        if(n%m==0)
                                break;
                }
                if(n==m)
                {
                        printf("%6d",n);
                        total++;
                        control++;
                        if(control%6==0)
                                printf("\n");
                }
        }
        return total;
}
int main(void)
{
        printf("\n  There are %d prime numbers here.", prime());
}
