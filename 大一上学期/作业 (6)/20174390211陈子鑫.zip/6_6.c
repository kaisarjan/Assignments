/*6_6*/
/*reverse numbers*/

#include <stdio.h>

int reverse(int num)
{
        int reversed=0;
        while(num)
        {
                reversed=reversed*10+(num%10);
                num=num/10;
        }
        return reversed;
}
int main(void)
{
        int num,m;
        printf("Please input a number:");
        scanf("%d",&num);
        m=num;
        printf("%d reversed is %d",m,reverse(num));
}
