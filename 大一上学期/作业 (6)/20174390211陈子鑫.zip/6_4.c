/*6_4*/
/*The Pythagorean_triple*/

#include <stdio.h>

int Pythagorean_triple(int a, int b,int c)
{
        if(a*a+b*b==c*c)
                return 1;
        else return 0;
}
int main(void)
{
        int a,b,c,sum=0,control;
        for (a = 1; a < 1000; a++)
                for (b = 1; b < 1000; b++)
                        for (c = 1; c < 1000; c++)
                        {
                                if(Pythagorean_triple(a,b,c))
                                {
                                        printf("  %4d%4d%4d",a,b,c );
                                        sum++;
                                        control++;
                                        if(control%5==0)
                                                printf("\n");
                                }
                        }
        printf("\n   %d",sum/2 );
}
