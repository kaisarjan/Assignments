#include<stdio.h>
int fun(int a,int b)
{
    int n;
    if(a>b)
        n=b;
    for(;n>=1;n--)
    {
        if(a%n==0&&b%n==0)
           return n;
    }
}
main()
{
    int c,d,g;
    scanf("%d %d",&c,&d);
    g=fun(c,d);
    printf("���Լ��=%d\n",g);
}
