#include<stdio.h>
#include<math.h>
float aaa(float n,float x)
{
    float a=1,b,c=1;
    for(;a<=n;a++)
        c*=a;
    b=(float)pow((float)x,(float)n)/c;
    return b;
}
main()
{
    float x,n,s=1;
    scanf("%f %f",&x,&n);
    if(n!=0)
       {
           while(n)
              {
                 s=s+aaa(x,n);
                 n--;
              }
           printf("s=%f",s);
       }
    else
        printf("s=1");
}
