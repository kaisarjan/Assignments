#include<stdio.h>
double add(double a,double b)
{
	double c;
	c=a+b;
	return c;
}
main()
{
	double x,y,s;
    scanf("%lf%lf",&x,&y);
		s=add(x,y);
	printf("%lf",add(x,y));
	add(x,y);
}