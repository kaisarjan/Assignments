#include<stdio.h>
#include<math.h>
int fun(int a)//fun��ʾ�׳�
{
    int i,sum=1;
    for(i=1;i<=a;i++)
        sum=sum*i;
    return sum;
}
float cf(int a,int n)//cf��ʾ��a�ļ��η��ĺ���
{    int i,s=1;
    for(i=1;i<=n;i++)
        s=s*a;
    return s;
}
main()
{   float n,x,s=1,a;
    scanf("%f%f",&n,&x);
    for(a=1;a<=n;a++)
        s=s+cf(x,a)/fun(a);
    printf("\ns=%f\n",s);
}
