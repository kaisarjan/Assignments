#include<stdio.h>
int fun(int a,int b)
{
    if(a<b)
    {
        int x=b;
        b=a;
        a=x;
    }
    if(a%b==0)
        return b;
    else
        return fun(b,a%b);
}
main()
{
    int a,b,c;//cΪa��b�����Լ��
    printf("please input two numbers:");
    scanf("%d%d",&a,&b);
    printf("c=%d\n",fun(a,b));
}
