#include<stdio.h>
int fun(x)
{
    int m,n;
    for(m=1;m<x;m++)
    {
        for(n=1;n<x;n++)
        {
            if(m*m+n*n==x*x)
                return x;
        }
    } return 0;
}
main()
{
    int i,count=0,y;
   for(i=1;i<=1000;i++)
   {
       if(fun(i))
        {
            y=fun(i);
           printf("%4d",y);
           count++;
        }
    }
          printf("%d\n",count);
}
