#include<stdio.h>
#include<math.h>
main()
{  int a,b;
    scanf("%d",&a);
    b=yx(a);
    printf("%d",b);
}
  int yx(int a)
{     int s=0;
       while(a>0)
       {
           s=s*10+a%10;
           a=a/10;
       }
     return s;
}
15%5%

4

4

4
477777777777777777777777777777777777777
4
