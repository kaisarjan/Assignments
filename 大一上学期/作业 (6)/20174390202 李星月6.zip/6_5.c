double n_n(int);
double x_n(int,int);
main()
{
    int n,x,i;
    double s=1;
    printf("������x,n\n");
    scanf("%d,%d",&x,&n);
    for(i=1;i<=n;i++)
        s+=x_n(x,i)/n_n(i);
    printf("\nsum=%lf\n",s);
}
double n_n(int n)
{
    int i,m=1;
    for(i=1;i<=n;i++)
        m=m*i;
    return m;
}
double x_n(int x,int n)
{
    int i,s=0;
    if(n=1)
        x=x;
    else
        for(i=2;i<=n;i++)
        x=x*x;
    return x;
}
