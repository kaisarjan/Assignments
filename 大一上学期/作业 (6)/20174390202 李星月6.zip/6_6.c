#include<stdio.h>
int backwords(int);
main()
{
    int n,k;
    printf("������һ������\n");
    scanf("%d",&n);
    k=backwords(n);
}
int backwords(int n)
{
    int m;
    m=n;
    for(;m!=0;)
    {
        printf("%d",m%10);
        m=m/10;
    }
    return 1;
}
