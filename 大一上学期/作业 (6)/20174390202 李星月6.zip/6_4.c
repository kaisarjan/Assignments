#include<stdio.h>
int hongshu(int n)
{
    int a,b;
    for(a=0;a<n;a++)
    {
        for(b=0;b<n;b++)
        {
            if(a*a+b*b==n*n)
            {
                //printf("\n%d&%d\n",a,b);
                return 1;
            }
        }
    }
    return 0;
}
main()
{
    int n,count=0;
    printf("1000�������к���\n");
    for(n=1;n<1001;n++)
    {
        if(hongshu(n))
        {
            printf("%d\n",n);
            count++;
        }
    }
    printf("����%d��",count);
}
