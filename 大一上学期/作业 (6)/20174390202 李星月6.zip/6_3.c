#include<stdio.h>
int gcd(int m,int n)
{
    int a=m,i;
	if(a>n)
		a=n;
	for(i=n;i>=1;i--)
		if(m%i==0&&n%i==0)
			return i;
		return 0;
}
main()
{
	int m,n;
	scanf("%d%d",&m,&n);
	printf("%d\n",gcd(m,n));
}