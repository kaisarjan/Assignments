#include<stdio.h>
int add(int m,int n)
{
	return m+n;
}
main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	printf("%d\n",add(a,b));
}