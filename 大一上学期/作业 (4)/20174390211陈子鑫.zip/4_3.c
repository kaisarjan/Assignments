/*4_3*/
/*leap yrs problem*/

#include<stdio.h>

int main(void)
{
    int n=1,sum=0;
    while(n<2017)
    {
        n++;
        if(n%4==0&&n%100!=0||n%400==0)
        {
            printf("%4d ",n);
            sum++;
            if(sum%5==0)
            printf("\n");
        }
    }
    printf("\nThere are %d leap years in total.",sum);
}
