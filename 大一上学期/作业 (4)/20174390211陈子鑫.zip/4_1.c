/*4_1*/
/*print from 1 to 1000*/

#include<stdio.h>

int main(void)
{
    int n=1;
    while(n<=1000)
    {
        printf("%4d ",n);
        n++;

    }
}
