/*4_2*/
/*sum of odd number less than 1000*/

#include<stdio.h>

int main(void)
{
    int n=1,sum=1;
    while(n<1000)
    {
        n++;
        if(n%2!=0)
            sum=sum+n;
    }
    printf("%d",sum);
}
