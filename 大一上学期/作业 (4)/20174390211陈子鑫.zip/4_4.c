/*4_4*/
/*reverse number input*/

#include<stdio.h>

int main(void)
{
    int reversed=0,num,m;
    printf("Please input a number:");
    scanf("%d",&num);
    m=num;
    while(num)
    {
        reversed=reversed*10+(num%10);
        num=num/10;
    }
    printf("%d reversed is %d",m,reversed);
}
