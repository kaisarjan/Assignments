#include<stdio.h>
main()
{
	int i=0;
	while(i>=0&&i<1000)
	{	i++;
	printf("%d\t",i);
	}

}
