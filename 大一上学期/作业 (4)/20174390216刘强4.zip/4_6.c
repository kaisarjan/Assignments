#include<stdio.h>
main()
{
	int a=1,num=0;
    while(a>=1&&a<=1000)
	{
	    a++;
	    if(a%3==0&&a%5!=0)
        printf("%d\t",a);
        if(a%3==0&&a%5!=0)
       num++;
    }
printf("num=%d\n",num);
}
