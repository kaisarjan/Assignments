#include<stdio.h>
main()
{
	int i,sum=0;
	for(i=1;i<1000;i+=2)
		sum+=i;
	printf("%d",sum);
}
