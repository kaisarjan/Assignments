#include<stdio.h>
main()
{
	int x,y,m,i,a=1;
	scanf("%d %d",&x,&y);
	printf("please put in two numbers");
	while(x<=0||y<=0)
	{printf("error");}
	    m=x;
	    if(x<y)
        {
            x=y;
            y=m;
        }
		   for(i=2;i<=y;i++)
           {
               if(x%i==0&&y%i==0)
                a=i;
           }
           printf("%d\n",a);
           m=(x*y)/a;
           printf("%d\n",m);

}
