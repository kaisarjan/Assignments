#include<stdio.h>
main()
{
	int i=1,sum=0;
	while(i<=1000)
	{
		sum=sum+i;
		i+=2;
	}
	printf("%d\n",sum);
}
