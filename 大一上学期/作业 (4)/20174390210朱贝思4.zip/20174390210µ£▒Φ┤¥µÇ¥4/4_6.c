#include<stdio.h>
main()
{
    int x=0,count=0;
    while(x<=1000)
    {
        x++;
        if(x%3==0&&x%5!=0)
         {
             printf("%5d",x);
             count++;
         }
    printf("%d\n",count);
    }
}
