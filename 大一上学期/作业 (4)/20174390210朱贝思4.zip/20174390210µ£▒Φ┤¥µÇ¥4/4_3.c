#include<stdio.h>
main()
{
	int n=0,count=0;
	while(n<=2017)
	{
	    n++;
		if(n%4==0&&n%100!=0||n%400==0)
		{
			count+=1;
			printf("%16d",n);
		}
	}
	printf("%d\n",count);
}
