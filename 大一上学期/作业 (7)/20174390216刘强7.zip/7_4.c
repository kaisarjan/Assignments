#include<stdio.h>
double fun(int m)
{
	int n;
	double a,b,c,d;
	n=1;
	a=1;
	while(n<=m)
        {   b=2.0*n;
	        c=b-1.0;
		    d=b+1.0;
		    a=a*b*b/c/d;
		    n++;
	    }
	return a;
}
main()
{
	printf("%lf\n",fun(10));
}
