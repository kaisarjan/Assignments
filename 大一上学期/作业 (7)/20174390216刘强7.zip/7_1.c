#include<stdio.h>
int fun(int n)
{
	int m;
	if(n==1)
		m=1;
	else
		m=n*fun(n-1);
	return m;
}
main()
{
	int a,sum=0;
	for(a=1;a<10;a++)
		sum+=fun(a);
	printf("%d\n",sum);
}
