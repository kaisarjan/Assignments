#include <stdio.h>
main( )
{
  int a,b;
  b=fun(8);
  for(a=1;a<8;a++)
	 b=b*2;
  printf("b=%d\n",b);
}
int fun(int m)
{
  int a,j,n=1,sum;
  for(a=1;a<=765;a++)
  {   sum=a;
      n=a;
	  for(j=1;j<m;j++)
	  {  n=n*2;
        sum=sum+n;
	  }
	  if(sum==765)  break;
   }
  return a;
}
