#include<stdio.h>
double fun(double x,int n)
{
  int a,c=1,b=1;
  double s=1,j=1;
  for(a=1;a<=2*n;a++)
{
	  j=j*x;
	  c=c*a;
	  if(a%2==0)
    {
	      b=-b;s=s+b*j/c;
    }
}
  return s;
}
main()
{
	double x=5.6;
	int n=7;
	double p,q,t,y;
	p=fun(x,n);
	q=fun(x+2.3,n);
	t=fun(x-3.2,n+3);
    y=p/(q+t);
	printf("y=%lf\n",y);
}
