#include <stdio.h>
#include <math.h>
float numerator(int k)
{
        return pow(2*k,2);
}
int denominator(int k)
{
        return (2*k-1)*(2*k+1);
}
double r(int k)
{
        return (double)numerator(k)/denominator(k);
}
main()
{
        int k,i;
        double sum=1;
        scanf("%d",&i);
        for(k=1; k<=i; k++)
        {
                sum*=r(k);
        }
        printf("result:%f",sum);
}
