#include <stdio.h>

int factorial(int m)
{
        if(m==1)
                return 1;
        else return factorial(m-1)*m;
}
int main(void)
{
        int m,n=0;
        for(m=1; m<=10; m++)
        {
                n=n+factorial(m);
        }
        printf("\n%d",n );
}
