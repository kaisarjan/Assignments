#include <stdio.h>

int light(int n,int m)
{
        if(n==1)
                return m;
        else return light(n-1,m)/2;
}
main()
{
        int sum=0,n,m;
        for(m=765; m>0; m--) {
                for(n=8; n>0; n--)
                {
                        sum+=light(n,m);
                }
                if(sum==765)
                {
                        printf("%d",m);
                        break;
                }
                sum=0;
        }
}
