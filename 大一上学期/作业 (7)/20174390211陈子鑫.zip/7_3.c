#include <stdio.h>
#include <math.h>
int factorial(int m)
{
        if(m==1)
                return 1;
        else return factorial(m-1)*m;
}
float f(float x,float n)
{
  int sum=0,m;
  for(m=n;m!=0;m--)
  sum=sum+(pow((-1),n)*pow(x,2*n))/factorial(n);
  return sum;
}
int main(void)
{
        float y,x=5.6,n=7;
        y=f(x,n)/(f(x+2.3,n)+f(x-3.2,n+3));
           printf("%f\n",y );
}
