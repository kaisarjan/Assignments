#include<stdio.h>
float fz(int);
float fm(int);
main()
{
    int k,i;
    double s=1;
    printf("input k\n");
    scanf("%d",&k);
    for(i=1;i<=k;i++)
        s*=fz(i)/fm(i);
    printf("s=%f\n",s);
}
float fz(int n)
{
    int f;
    f=(2*n)*(2*n);
    return f;
}
float fm(int n)
{
    int f;
    f=(2*n-1)*(2*n+1);
    return f;
}
