#include<stdio.h>
int fun(int n)
{
    int f;
    if(n==1)
        f=1;
    else
        f=n*fun(n-1);
    return f;
}
main()
{
    int n,sum=0;
    for(n=1;n<=10;n++)
        sum+=fun(n);
    printf("%d\n",sum);
}
