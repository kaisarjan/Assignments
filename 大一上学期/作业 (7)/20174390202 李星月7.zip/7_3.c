#include<stdio.h>
#include<math.h>
double f(float,int);
int fun(int);
main()
{
    float x=5.6,n=7;
    double y;
    y=f(x,n)/(f(x+2.3,n)+f(x-3.2,n+3));
    printf("\ny=%f\n",y);
}
int fun(int n)
{
    int f;
    if(n==0)
        f=1;
    else
        f=n*fun(n-1);
    return f;
}
double f(float x,int n)
{
    int i;
    double sum=0;
    for(i=0;i<=n;i++)
        sum+=(pow(-1,i)*pow(x,2*i))/fun(2*i);
    return sum;
}
