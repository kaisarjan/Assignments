#include<stdio.h>
int dideng(int n)
{
    int sum=0,c,d;
    d=n;
    for(c=1;c<=8;c++)
    {
        sum+=d;
        d/=2;
    }
    return sum;
}
main()
{
    int i,all;
    for(i=1;i<=765;i++)
    {
        all=dideng(i);
        if(all==765)
            printf("%d\n",i);
    }
}
