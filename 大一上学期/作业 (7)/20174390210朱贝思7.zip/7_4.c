#include<stdio.h>
float f(float k)
{
    float c;
    if(k==1)
    c=3;
    else c=(2*k+1)*(2*k-1)*f(k-1);
    return c;
}
main()
{
    int k;
    float s,i,d=1.0;
    scanf("%d",&k);
    for(i=1.0;i<=k;i++)
    {    d=d*4*i*i;
        s=d/f(i);
    }
    printf("%f",s);
}
