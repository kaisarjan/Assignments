#include<stdio.h>
int fun(int n)
{
    int c;
    if(n==1)
        c=1;
    else c=n*fun(n-1);
    return c;
}
main()
{
    int n,sum=0;
    for(n=1;n<=10;n++)
        sum=sum+fun(n);
    printf("%d\n",sum);
}
