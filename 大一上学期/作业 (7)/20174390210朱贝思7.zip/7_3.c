#include<stdio.h>
float f(float x,float n)
{    int i,m=1,c=1;
    float s=1.0,w=1;
    for(i=1;i<=2*n;i++)
    {
        w=w*x;
        c=c*i;
        if(i%2==0)
        {
            m=-m;
            s=s+m*w/c;
        }
    }   return s;
}
main()
{
    float x,s;
    int n;
    scanf("%f%d",&x,&n);
    s=f(x,n)/(f(x+2.3,n)+f(x-3.2,n+3));
    printf("%f\n",s);
}

