#include<stdio.h>
int fun(int n)
{
    int c;
    if(n==1)
        c=1;
    else c=fun(n-1)*2;
    return c;
}
main()
{
    int n,i,s=0;
    for(n=1;n<=8;n++)
       s=s+fun(n);
    i=765/s*fun(8);
    printf("%d\n",i);
}
