#include<stdio.h>
int fun(int n)
{
    int i;
    for(i=2;i<n;i++)
        if(n%i==0)
           return 0;
        if(i==n)
           return 1;
        else return 0;
}
main()
{
    int i=100,n,count=0,x;
    for(i=100;i<=9999;i++)
     {
              if(fun(i))
           {    n=i;
                while(n!=0)
                 { n=n/10;
                   if(!fun(n))
                     break;
                  }
             if(n==0)     {  printf("%d\t",i);   count+=1; x=i;}

           }
      }
       printf("%d\n",count);
       printf("%d\n",x);
}
