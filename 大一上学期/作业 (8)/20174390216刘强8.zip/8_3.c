#include <stdio.h>
int sp(int n)
{
int t, i,m;
for(i = 1;i <= n;i++)
{
t= n % i;
if(t==0&&i!= 1&&i!= n||n==1)
{
m = 0;
break;
}
else m = 1;
}
return m;
}
int spor(int n)
{
int m,y,z;
y = n / 10;
z = n / 100;
if(sp(n))
if(sp(y))
m =	sp(z);
return m;
}
main()
{
int n,max=0,i=0,sum=0;
for(n=100;n<=999;n++)
{
if(spor(n)==1)
{
i++;
sum=sum+n;
max=n;
}
}
for(n=1000;n<=9999;n++)
{
if(spor(n)==1)
{
if(sp(n/1000)==1)
{
i++;
sum=sum+n;
max=n;
}printf("%5d\t",n);
}
}
printf("������������Ϊ%d\n���ĳ�������Ϊ%d\n",i,max);
}
