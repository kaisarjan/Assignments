#include<stdio.h>
int prime(int m)
{
    int i;
    for(i=2;i<m;i++)
        if(m%i==0)
        break;
    if(i==m)
        return 1;
    return 0;
}
main()
{
    int x,i,count=0,max;
    for(x=100;x<=9999;x++)
    {
        for(i=x;i>0;)
        {
            if(prime(i))
                i/=10;
            else break;
        }
        if(i==0)
        {
            count++;
            max=x;
            printf("%d\t",x);
        }
    }
    printf("\ncount=%d,max=%d\n",count,max);
}
