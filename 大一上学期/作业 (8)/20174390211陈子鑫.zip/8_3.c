#include <stdio.h>

int prime(int num)
{
        int m;
        if(num>1)
        {
                for(m=2; m<num; m++)
                        if(num%m==0)
                                return 0;
                return 1;
        }
        return 0;
}
int super(int num)
{
        for(; num!=0; num/=10)
                if(!prime(num))
                        return 0;
        return 1;
}
int main(void)
{
        int num,total=0,max=0;
        for(num=100; num<10000; num++)
                if(super(num))
                {
                        printf("%d\n",num );
                        total++;
                        max=num;
                }
        printf("total:%dmax:%d\n", total,max);
}
